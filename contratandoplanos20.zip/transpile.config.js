module.exports = {
  transpilePackages: ["pdfkit", "pdf-lib"],
}

