"use client"

export default function AdminHeader() {
  return (
    <header className="bg-white border-b border-gray-200 h-16">
      <div className="flex items-center justify-between h-full px-4">
        <div></div>
      </div>
    </header>
  )
}

