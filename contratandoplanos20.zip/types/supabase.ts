export type Database = {
  public: {
    Tables: {
      // Defina suas tabelas aqui se necessário
    }
    Views: {
      // Defina suas views aqui se necessário
    }
    Functions: {
      // Defina suas funções aqui se necessário
    }
  }
}

