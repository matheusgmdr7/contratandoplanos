export interface Corretor {
  id: number
  nome: string
  email: string
  whatsapp: string
  estado: string
  created_at: string
}

